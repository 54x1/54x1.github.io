<?php
//load bootstrap

function load_bootstrap() {
    wp_enqueue_style('bootstrap4', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
    wp_enqueue_script( 'boot1','https://code.jquery.com/jquery-3.5.1.slim.min.js', 'jquery', '1.0', true);
    wp_enqueue_script( 'boot2','https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js', 'jquery', '1.0', true);
    wp_enqueue_script( 'boot3','https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', 'jquery', '1.0', true);
}
add_action( 'wp_enqueue_scripts', 'load_bootstrap' );

//loads css
function load_stylesheets(){
  wp_register_style('stylesheet', get_template_directory_uri().'/style.css', array(), 1.0, 'all');
  wp_enqueue_style('stylesheet');

  wp_register_style('main', get_template_directory_uri().'/css/main.css', array(), 1.0, 'all');
  wp_enqueue_style('main');
}
add_action('wp_enqueue_scripts', 'load_stylesheets');

//loads js
function load_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script( 'customjs', get_template_directory_uri() . '/js/customjs.js', 'jquery', '1.0', true);
}
add_action( 'wp_enqueue_scripts', 'load_scripts' );



//Theme Options
add_theme_support('menus');

//Menus
register_nav_menus(
  array(

  )
);
?>
